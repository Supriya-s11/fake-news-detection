"""
Train a TF-IDF + Logistic Regression fake-news text classifier.

Dataset options:
1. Put Fake.csv and True.csv in data/ (Kaggle-style files), OR
2. Put a single data/news.csv with columns: text,label
   Labels may be Fake/Real or 0/1.

This project does not include a large third-party dataset. See README.md.
"""
from pathlib import Path
import re
import joblib
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
MODEL_DIR = ROOT / "models"
MODEL_PATH = MODEL_DIR / "fake_news_pipeline.joblib"


def clean_text(text):
    text = str(text).lower()
    text = re.sub(r"http\S+|www\.\S+", " ", text)
    text = re.sub(r"[^a-z\s]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def load_dataset():
    fake_path = DATA_DIR / "Fake.csv"
    real_path = DATA_DIR / "True.csv"
    combined_path = DATA_DIR / "news.csv"

    if fake_path.exists() and real_path.exists():
        fake = pd.read_csv(fake_path)
        real = pd.read_csv(real_path)
        fake["label"] = "Fake"
        real["label"] = "Real"
        data = pd.concat([fake, real], ignore_index=True)
        text_columns = [c for c in ["title", "text", "subject"] if c in data.columns]
        if not text_columns:
            raise ValueError("Fake.csv and True.csv need a title or text column.")
        data["text"] = data[text_columns].fillna("").astype(str).agg(" ".join, axis=1)
        return data[["text", "label"]]

    if combined_path.exists():
        data = pd.read_csv(combined_path)
        if not {"text", "label"}.issubset(data.columns):
            raise ValueError("data/news.csv must contain 'text' and 'label' columns.")
        return data[["text", "label"]]

    raise FileNotFoundError(
        "Dataset not found. Add data/Fake.csv and data/True.csv, "
        "or create data/news.csv with text,label columns. See README.md."
    )


def normalize_label(value):
    value = str(value).strip().lower()
    if value in {"fake", "false", "0"}:
        return "Fake"
    if value in {"real", "true", "1"}:
        return "Real"
    raise ValueError(f"Unsupported label: {value!r}. Use Fake/Real or 0/1.")


def main():
    data = load_dataset().dropna(subset=["text", "label"]).copy()
    data["label"] = data["label"].map(normalize_label)
    data["text"] = data["text"].map(clean_text)
    data = data[data["text"].str.len() > 0].drop_duplicates(subset=["text"])

    if data["label"].nunique() != 2 or data["label"].value_counts().min() < 2:
        raise ValueError("Need at least two examples for each of the two labels.")

    X_train, X_test, y_train, y_test = train_test_split(
        data["text"], data["label"], test_size=0.2, random_state=42,
        stratify=data["label"]
    )

    pipeline = Pipeline([
        ("tfidf", TfidfVectorizer(stop_words="english", max_df=0.95, min_df=2,
                                  ngram_range=(1, 2), max_features=100000)),
        ("classifier", LogisticRegression(max_iter=1000, class_weight="balanced"))
    ])
    pipeline.fit(X_train, y_train)
    predictions = pipeline.predict(X_test)

    print(f"Dataset rows used: {len(data):,}")
    print(f"Train rows: {len(X_train):,} | Test rows: {len(X_test):,}")
    print(f"Accuracy: {accuracy_score(y_test, predictions):.4f}")
    print("\nClassification report:")
    print(classification_report(y_test, predictions, zero_division=0))
    print("Confusion matrix (label order: Fake, Real):")
    print(confusion_matrix(y_test, predictions, labels=["Fake", "Real"]))

    MODEL_DIR.mkdir(exist_ok=True)
    joblib.dump(pipeline, MODEL_PATH)
    print(f"\nSaved model to: {MODEL_PATH}")


if __name__ == "__main__":
    main()
