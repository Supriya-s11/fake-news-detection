# Fake News Detection System

A beginner-friendly machine-learning project that classifies news text as **Fake** or **Real** using TF-IDF features and Logistic Regression. A Streamlit interface lets users enter a headline or article and view a prediction.

> **Important:** The model is a text classifier, not a reliable fact-checking authority. Its performance depends on the dataset and may not generalize to current events or unfamiliar topics.

## Features

- Text preprocessing
- TF-IDF vectorization with unigrams and bigrams
- Logistic Regression classifier
- Stratified train/test split
- Accuracy, precision, recall, F1-score and confusion matrix
- Streamlit prediction interface
- Class weighting to help with imbalanced labels

## Project structure

```text
fake-news-detection/
├── app.py
├── train_model.py
├── requirements.txt
├── README.md
├── .gitignore
├── data/
│   └── README.md
└── models/
    └── .gitkeep
```

## 1. Get a dataset

This repository intentionally does not bundle a large third-party dataset.

Option A: use a public Kaggle-style fake/real news dataset with two files named `Fake.csv` and `True.csv`. Put both files in the `data/` folder.

Option B: create `data/news.csv` with exactly two columns named `text` and `label`. Labels can be `Fake`/`Real` or `0`/`1`.

Use a dataset you are permitted to use, and check its source and license before redistribution. Do not upload private or restricted data.

## 2. Install dependencies

Python 3.10 or 3.11 is recommended.

```bash
python -m venv .venv
```

Activate the environment:

- Windows: `.venv\Scripts\activate`
- macOS/Linux: `source .venv/bin/activate`

Then run:

```bash
pip install -r requirements.txt
```

## 3. Train and evaluate

After placing the dataset in `data/`, run:

```bash
python train_model.py
```

The script prints the dataset size, accuracy, classification report and confusion matrix. It saves the fitted pipeline to `models/fake_news_pipeline.joblib`.

**Report only the metrics you actually obtain** when you run the script on your chosen dataset.

## 4. Launch the app

```bash
streamlit run app.py
```

Open the local URL printed in the terminal, paste news text, and click **Check news**.

## Model workflow

1. Load the labeled news dataset.
2. Clean and combine available text fields.
3. Split the data into training and testing sets.
4. Convert text into TF-IDF features.
5. Train Logistic Regression with balanced class weights.
6. Evaluate on the held-out test set.
7. Save the pipeline and use it in the Streamlit app.

## Limitations

- A high test score does not prove that a particular article is true or false.
- Dataset leakage, duplicates, publisher names, or writing style can inflate scores.
- The confidence shown by the app is not a verified probability that the prediction is correct.
- This starter project uses class weighting, not SMOTE. If you experiment with SMOTE, apply it only to the training split and compare results carefully.

## Possible improvements

- Add cross-validation and error analysis.
- Compare Logistic Regression with Linear SVM.
- Add a source/URL verification step.
- Test on a separate, newer dataset.
- Add unit tests and deploy the Streamlit app.

## Resume note

Once you have trained and tested the project, update your resume with the actual dataset size and measured metrics. Do not claim a 94% score or SMOTE unless your implementation and evaluation support those claims.
