from pathlib import Path
import joblib
import streamlit as st

MODEL_PATH = Path(__file__).resolve().parent / "models" / "fake_news_pipeline.joblib"

st.set_page_config(page_title="Fake News Detection", page_icon="📰")
st.title("📰 Fake News Detection")
st.write(
    "Enter a headline or article. The model predicts a label based on patterns "
    "learned from its training dataset."
)

if not MODEL_PATH.exists():
    st.warning("The trained model was not found. Train it first using: python train_model.py")
    st.stop()

model = joblib.load(MODEL_PATH)
article = st.text_area("News text", height=220, placeholder="Paste a headline or article here...")

if st.button("Check news", type="primary"):
    if not article.strip():
        st.error("Please enter some news text.")
    else:
        prediction = model.predict([article])[0]
        probabilities = model.predict_proba([article])[0]
        confidence = float(max(probabilities)) * 100

        if prediction == "Fake":
            st.error(f"Prediction: {prediction}")
        else:
            st.success(f"Prediction: {prediction}")

        st.metric("Model confidence", f"{confidence:.1f}%")
        st.caption(
            "This is a machine-learning prediction, not a fact-check. "
            "It can be wrong, especially for unfamiliar topics or misleading training data."
        )
