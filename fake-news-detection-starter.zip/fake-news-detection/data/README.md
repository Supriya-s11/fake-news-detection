Place your dataset here; large datasets are not included in this repository.

Supported:
- Fake.csv and True.csv (Kaggle-style files), or
- news.csv with columns `text,label`.

See the root README.md for setup instructions. Check dataset licensing before sharing data.
